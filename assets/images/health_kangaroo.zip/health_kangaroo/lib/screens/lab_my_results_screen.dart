import 'package:flutter/material.dart';
class LabMyResultsScreen extends StatefulWidget {
  const LabMyResultsScreen({Key? key}) : super(key: key);

  @override
  State<LabMyResultsScreen> createState() => _LabMyResultsScreenState();
}

class _LabMyResultsScreenState extends State<LabMyResultsScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
