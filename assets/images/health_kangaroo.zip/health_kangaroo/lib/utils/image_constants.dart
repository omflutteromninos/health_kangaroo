

class ImageConstants{
  String appLogo = 'assets/icons/hk_logo.png';
  String femaleImage = 'assets/images/female.png';

}